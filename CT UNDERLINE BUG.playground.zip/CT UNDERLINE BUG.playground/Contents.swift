import Cocoa

import PlaygroundSupport

// Core text rendering bug:
// render a "123" attributed text with different colours and underline.
// Look at the rendered layer:
// the underline goes beyond the text and underline colours are not aligned with respective char


var demoView = NSView(frame: CGRect(x: 0, y: 0, width: 300, height: 300))
demoView.wantsLayer = true
PlaygroundPage.current.liveView = demoView

var layer = TextDrawingLayer()

// Set the properties
layer.bounds = CGRect(x: 0, y: 0, width: 300, height: 300)
layer.position = CGPoint(x: 300/2, y: 300/2)
layer.backgroundColor = NSColor.white.cgColor
layer.borderWidth = 3
layer.borderColor = NSColor.black.cgColor

// Add the layer
demoView.layer?.addSublayer(layer)
demoView.setNeedsDisplay(demoView.bounds)
layer.setNeedsDisplay()

class TextDrawingLayer: CALayer {
    override func draw(in ctx: CGContext) {
        let font = NSFont.systemFont(ofSize: 20)
        let allRange = NSMakeRange(0, 1)
        
        // Create an underlined attributed string "123" with different colours, creating a char at a time
        
        // "1" underlined black
        let str1 = NSMutableAttributedString(string: "1")
        str1.addAttribute(NSAttributedString.Key.underlineStyle, value: 1, range: allRange)
        str1.addAttribute(NSAttributedString.Key.underlineColor, value: NSColor.black, range: allRange)
        str1.addAttribute(NSAttributedString.Key.font, value: font, range: allRange)
        str1.addAttribute(NSAttributedString.Key.foregroundColor, value: NSColor.black, range: allRange)
        
        // "2" underlined red
        let str2 = NSMutableAttributedString(string: "2")
        str2.addAttribute(NSAttributedString.Key.underlineStyle, value: 1, range: allRange)
        str2.addAttribute(NSAttributedString.Key.underlineColor, value: NSColor.red, range: allRange)
        str2.addAttribute(NSAttributedString.Key.font, value: font, range: allRange)
        str2.addAttribute(NSAttributedString.Key.foregroundColor, value: NSColor.red, range: allRange)
        
        // "3" underlined black
        let str3 = NSMutableAttributedString(string: "3")
        str3.addAttribute(NSAttributedString.Key.underlineStyle, value: 1, range: allRange)
        str3.addAttribute(NSAttributedString.Key.underlineColor, value: NSColor.black, range: allRange)
        str3.addAttribute(NSAttributedString.Key.font, value: font, range: allRange)
        str3.addAttribute(NSAttributedString.Key.foregroundColor, value: NSColor.black, range: allRange)
        
        // Join three pieces
        let resultString = NSMutableAttributedString()
        resultString.append(str1)
        resultString.append(str2)
        resultString.append(str3)
        print(resultString)
        
        // Draw using CT
        let line:CTLine = CTLineCreateWithAttributedString(resultString)
        ctx.textPosition = CGPoint(x: 150, y: 150)
        CTLineDraw(line, ctx)
    }
}
